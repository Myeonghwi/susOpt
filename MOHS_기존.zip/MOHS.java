package org.SUSCOM.Algorithms.MOHS;

import java.util.ArrayList;

import org.SUSCOM.MainGUI;

public class MOHS {

	private double [] low; //row bound

	private double [] high; //upper bound

	private double [] NCHV;

	private int [] lowInt;

	private int [] highInt;

	private double [] bestFitHistory;

	private double [] worstFitHistory;

	private double[][] HM;

	private boolean terminationCriteria = true;

	public double [] bestHarmony;

	public double [][] ParetoSet;

	public int[] Type;

	public int nObjectives;

	public int VarType;

	public int NVAR;

	public int HMS;

	public int maxIter;

	public double PAR;

	public double PARmax;

	public double PARmin;

	public double BW;

	public double IntegerBW;

	public boolean IntegerPermuteRange;

	public boolean Flip;

	public double BWmax;

	public double BWmin;

	public boolean isVariableBW;

	public boolean isVariablePAR;

	public static double HMCR = .9;

	public double runTime;

	public int [] indices;

	public int generation;

	public IFunction fit;
	

	RandomGenerator randGen = new RandomGenerator(1234);

	ArrayList Ranges = new ArrayList();

	public MOHS() {
		//default parameters
		BW = 0.02;
		NVAR = 5;
		HMCR = .9;
		HMS = 5;
		PAR = .4;
		maxIter = 10000;
		generation = 0;
		isVariableBW = isVariablePAR = false;
		VarType = 1;
		nObjectives = 1;
	}

	private void setArray() {
		low = new double[NVAR];
		high = new double[NVAR];
		lowInt = new int[NVAR];
		highInt = new int[NVAR];

		NCHV = new double[NVAR];
		bestHarmony = new double[NVAR +1];
		bestFitHistory = new double[maxIter + 1];
		worstFitHistory = new double[maxIter + 1];
		HM = new double[HMS][NVAR + nObjectives];
		ParetoSet = new double[HMS][NVAR + nObjectives];
	}

	private void initiator() {
		double[] curFit;

		//save the location index of integer parameters in the array list, "Ranges"
		int count = 0;
		indices = new int[NVAR];

		for(int i = 0; i < NVAR; i++) {
			if (Type[i] == 0)
				indices[i] = count++;

			if(isVariableBW) {
				if (BWmax <= 0) System.out.println("BWmax should be greater than Zero");
			}
			else
				BWmax = BW;

			if(isVariablePAR) {
				if(PARmin <= 0) System.out.println("PARmin should be greater than Zero");
			}
			else
				PARmin = PAR;
		}
		//not necessary0
		for( int i = 0; i < HMS; i ++)
			for( int j = 0; j < nObjectives; j++)
				HM[i][NVAR + j] = Double.MAX_VALUE;

		for( int i = 0; i < HMS; i++) {
			for(int j = 0; j < NVAR; j++) {
				if (Type[j] == 1)
					HM[i][j] = randGen.randVal(low[j], high[j]);
				/*
			     else //�̻��϶�
                 {
                     int len = ((double[])(Ranges.toArray(indices[j]).ElementAt(indices[j]))).Length;
                     HM[i][j] = ((double[])(Ranges.toArray().ElementAt(indices[j])))[randGen.randVal(0, len - 1)];
                 }
				 */
				NCHV[j] = HM[i][j];
			}
			curFit = fitness(NCHV);
			for (int k = 0; k < nObjectives; k++)
				HM[i][NVAR + k] = curFit[k];
		}
	}
	public void setBounds(double low[], double high[]) {

		setArray();
		this.low = low;
		this.high = high;
	}

	public double[] fitness(double[] x) {
		return fit.F(x);
	}

	public boolean stopCondition() {
		if (generation > maxIter)
			terminationCriteria = false;
		return terminationCriteria;
	}

	public void updateHarmonyMemory(double[] newFitness) {
		if(nObjectives ==  1) {
			//find worst harmony
			double worst = HM[0][NVAR];
			int worstIndex = 0;
			for(int i = 0; i < HMS; i++)
				if( HM[i][NVAR] > worst) {
					worst = HM[i][NVAR];
					worstIndex = i;
				}

			worstFitHistory[generation] = worst;
			//update harmony
			if (newFitness[0] < worst) {
				for(int i = 0; i < NVAR; i++)
					HM[worstIndex][i] = NCHV[i];
				HM[worstIndex][NVAR] = newFitness[0];
			}

			//find best harmony
			double best = HM[0][NVAR];
			int bestIndex = 0;
			for(int i = 0; i < HMS; i++)
				if (HM[i][NVAR] < best) {
					best = HM[i][NVAR];
					bestIndex = i;
				}

			bestFitHistory[generation] = best;
			if (1 > 0) {
				for(int i = 0; i < NVAR; i++)
					bestHarmony[i] = HM[bestIndex][i];
			}
		}
		else
		{
			int sum = 0;
			for(int i = 0; i < HMS; i++) {
				sum = 0;

				for( int j = 0; j < nObjectives; j++)
					if(newFitness[j] <= HM[i][NVAR+j])
						sum++;
				if(sum == nObjectives) {
					for(int j = 0; j < nObjectives; j++)
						HM[j][NVAR+j] = newFitness[j];
					for(int k = 0; k < NVAR; k++)
						HM[i][k] = NCHV[k];
					break;
				}
			}
		}
	}



	private void memoryConsideration(int varIndex)
	{

		NCHV[varIndex] = HM[randGen.randVal(0, HMS - 1)][varIndex];
	}

	private void pitchAdjustment(int varIndex)
	{

		double rand = randGen.ran1();
		double temp = NCHV[varIndex];

		if (Type[varIndex] == 1)   /* REAL VARIABELS  */ 
		{
			if (rand < 0.5)
			{
				temp += rand * GetBW();
				if (temp < high[varIndex])
					NCHV[varIndex] = temp;
			}
			else
			{
				temp -= rand * GetBW();
				if (temp > low[varIndex])
					NCHV[varIndex] = temp;
			}
		}
		else /* NON-REAL VARIABELS  */ 
		{
			if (IntegerPermuteRange)
			{
				/*
				int len = ((double[])(Ranges.ToArray().ElementAt(indices[varIndex]))).Length;
				NCHV[varIndex] = ((double[])(Ranges.ToArray().ElementAt(indices[varIndex])))[randGen.randVal(0, len - 1)];
				 */
			}
			else if (Flip)  // for 0,1 cases
				if (NCHV[varIndex] == 0)
					NCHV[varIndex] = 1;
				else
					NCHV[varIndex] = 0;
			else
			{

				if (rand < 0.5)
				{
					temp += IntegerBW;
					if (temp < highInt[varIndex])
						NCHV[varIndex] = temp;
				}
				else
				{
					temp -= IntegerBW;
					if (temp > lowInt[varIndex])
						NCHV[varIndex] = temp;
				}
			}

		}

	}

	private void randomSelection(int varIndex)
	{
		if (Type[varIndex] == 1)
			NCHV[varIndex] = randGen.randVal(low[varIndex], high[varIndex]);
		/*	else
		{
			int len = ((double[])(Ranges.toArray().ElementAt(indices[varIndex]))).Length;
			NCHV[varIndex] = ((double[])(Ranges.toArray().ElementAt(indices[varIndex])))[randGen.randVal(0, len - 1)];
		}*/
	}

	public void Solve(IFunction f)
	{	
		//DateTime t1 = DateTime.Now;
		this.fit = f;
		initiator();

		while (stopCondition())
		{

			for (int i = 0; i < NVAR; i++)
			{
				if (randGen.ran1() < HMCR)
				{
					memoryConsideration(i);
					if (randGen.ran1() < PAR)
						pitchAdjustment(i);
				}
				else
					randomSelection(i);
			}

			double[] currentFit;
			currentFit = fitness(NCHV);
			updateHarmonyMemory(currentFit);
			generation++;
		}

		//DateTime t2 = DateTime.Now;
		//TimeSpan ts = t2 - t1;
		//runTime = ts.TotalSeconds;

	}

	private double GetBW()
	{
		double val;
		double c = Math.log(BWmin / BWmax) / maxIter;
		if (isVariableBW)
			val = BWmax * Math.exp(c * generation);
		else
			val = BWmax;
		return val;


	}

	private double GetPAR()
	{
		double val;
		if (isVariablePAR)
			val = (PARmax - PARmin) / (maxIter) * generation + PARmin;
		else
			val = PARmin;
		return val;
	}

	public void choosePareto()
	{

		int cntr = 0;
		for (int i = 0; i < HMS; i++)
		{/*
			for (int j = 0; j < HMS; j++)
			{
				if (i != j && HM[i][NVAR] >= HM[j][NVAR] && HM[i][NVAR + 1] > HM[j][NVAR + 1]) goto L100;
				if (i != j && HM[i][NVAR] > HM[j][NVAR] && HM[i][NVAR + 1] >= HM[j][NVAR + 1]) goto L100;
			}
		 */
			for (int j = 0; j < nObjectives; j++)
				ParetoSet[cntr][j] = HM[i][NVAR + j];
			for (int j = nObjectives; j < nObjectives + NVAR; j++)
				ParetoSet[cntr][j] = HM[i][j - nObjectives];
			cntr++;
			//			L100:
			//				;
		}


	}
	
	
	public double[][] MOHSstart()
    {
        costOptimizer co = new costOptimizer();
        co.Solve();
        
        return co.hs.ParetoSet;

    }
}//end class
