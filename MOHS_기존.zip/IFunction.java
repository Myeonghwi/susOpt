package org.SUSCOM.Algorithms.MOHS;

public interface IFunction {
	
	double[] F(double[] x);

}
