package org.SUSCOM.Algorithms.MOHS;

import org.SUSCOM.MainGUI;

public class Utility {

	//	public static String address = System.Environment.GetFolderPath(System.Environment.SpecialFolder.DesktopDirectory);
	//	static StreamWriter sw2;


	public static void WriteMatrix(double[][] M, String name, String format)
	{

		//		StreamWriter sw = File.CreateText(address + "\\" + name + ".txt");

		for (int i = 0; i < M.length; i++){
			for (int j = 0; j < M[i].length; j++)
			{
				//System.out.println(M[i][j]+"\t");


				//				sw.Write("{0}\t", M[i][j].ToString(format));  //"n8"
				//				if (j == M.GetLength(1) - 1)
				//					sw.WriteLine();
			}
			//System.out.println("\n");
		}



		//		sw.Close();
	}

}
